#pragma once

#include "game_core.h"
#include <stdbool.h>


typedef struct Move
{
    int pieceIndex;     // Index de la pièce dans le tableau pieces
    int direction;      // 0: Haut, 1: Bas, 2: Gauche, 3: Droite
    int fromX, fromY;   // Pour l'affichage 
    int toX, toY;       // Pour l'affichage 
} Move;

typedef struct Solution
{
    Move moves[200];    
    int count;          // Nb de coups
    bool found;         // solution trouvée ?
} Solution;

typedef struct
{
    GameState* data;
    int head,
    tail,
    count,
    capacity;
} SolverQueue;


Solution GameSolver_solve(GameCore* game);


