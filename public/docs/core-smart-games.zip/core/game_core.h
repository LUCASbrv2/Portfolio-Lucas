/*
    Copyright (c) Arnaud BANNIER, Nicolas BODIN.
    Licensed under the MIT License.
    See LICENSE.md in the project root for license information.
*/

#pragma once

#include "settings.h"

#include <stdbool.h>
#include <stdint.h>

#define GAME_GRID_SIZE 5
#define MAX_PIECES 10


typedef enum
{
    EMPTY = 0,
    HOLE,
    MUSHROOM,
    RABBIT,
    FOX_HEAD,
    FOX_TAIL
} CellType;

typedef enum
{
    ORIENTATION_VERTICAL, //POUR le renard (c tout)
    ORIENTATION_HORIZONTAL
} Orientation;


// Structure pour une pièce
typedef struct
{
    uint8_t id;
    uint8_t type;       // RABBIT ou FOX_HEAD
    uint8_t x, y;       // position
    uint8_t orientation; //renard uniquement
} Piece;

// État du jeu (Pièces mobiles uniquement)
typedef struct
{
    Piece pieces[MAX_PIECES];
    uint8_t piece_count;
} GameState;

// Cœur du jeu
typedef struct GameCore
{
    // Grille statique (Murs, Trous)
    uint8_t static_grid[GAME_GRID_SIZE][GAME_GRID_SIZE];

    GameState current_state;
    GameState initial_state;
    // nombres de mouvements 
    int moves_count;

    // mode de contrôle actuel (pour l'interface graphique)
    int currentMode; // 0=RABBIT, 1=FOX par ex
} GameCore;



bool GameCore_tryMove(const GameCore* game, const GameState* current, int piece_idx, int direction, GameState* new_state);
bool GameCore_checkWin(const GameCore* game);
void GameCore_buildFullGrid(const GameCore* game, const GameState* state, uint8_t grid[GAME_GRID_SIZE][GAME_GRID_SIZE]);



