#include "game/core/game_generate.h"
#include "game/core/game_hashmap.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define MAX_ATTEMPTS 50        
#define HASHMAP_INITIAL_CAPACITY 60000


static void GenQueue_init(GenQueue* q)
{
    q->capacity = 200000;
    q->data = (GameState*)malloc(sizeof(GameState) * q->capacity);
    q->depths = (int*)malloc(sizeof(int) * q->capacity);
    if (!q->data || !q->depths) exit(EXIT_FAILURE);
    q->head = 0;
    q->tail = 0;
    q->count = 0;
}

static void GenQueue_free(GenQueue* q)
{
    if (q->data) free(q->data);
    if (q->depths) free(q->depths);
}

static void GenQueue_clear(GenQueue* q)
{
    q->head = 0; q->tail = 0; q->count = 0;
}

static void GenQueue_push(GenQueue* q, GameState state, int depth)
{
    if (q->count >= q->capacity) return;
    q->data[q->tail] = state;
    q->depths[q->tail] = depth;
    q->tail = (q->tail + 1) % q->capacity;
    q->count++;
}

static GameState GenQueue_pop(GenQueue* q, int* outDepth)
{
    GameState state = q->data[q->head];
    if (outDepth) *outDepth = q->depths[q->head];
    q->head = (q->head + 1) % q->capacity;
    q->count--;
    return state;
}

static bool GenQueue_isEmpty(GenQueue* q)
{
    return q->count == 0;
}


// Vérifie si un état est gagnant 
static bool IsWinningState(const GameState* state, uint8_t staticGrid[GAME_GRID_SIZE][GAME_GRID_SIZE])
{
    for (int i = 0; i < state->piece_count; i++)
    {
        const Piece* p = &state->pieces[i];
        if (p->type == RABBIT)
        {
            // Conversion Visuel/Logique
            int visualRow = GAME_GRID_SIZE - 1 - p->y;
            if (staticGrid[visualRow][p->x] != HOLE)
            {
                return false;
            }
        }
    }
    return true;
}

static bool IsCellFreeForPlacement(GameCore* game, int x, int y)
{
    int visualY = GAME_GRID_SIZE - 1 - y;
    if (game->static_grid[visualY][x] != EMPTY) return false;

    for (int i = 0; i < game->current_state.piece_count; i++)
    {
        Piece* p = &game->current_state.pieces[i];
        if (p->x == x && p->y == y) return false;
        if (p->type == FOX_HEAD)
        {
            int tx = (p->orientation == ORIENTATION_VERTICAL) ? p->x : p->x + 1;
            int ty = (p->orientation == ORIENTATION_VERTICAL) ? p->y + 1 : p->y;
            if (tx == x && ty == y) return false;
        }
    }
    return true;
}

static void RandomPlacement(GameCore* game, int nbMushrooms)
{
    memset(game->static_grid, EMPTY, sizeof(game->static_grid));
    game->static_grid[0][0] = HOLE;
    game->static_grid[0][4] = HOLE;
    game->static_grid[2][2] = HOLE;
    game->static_grid[4][0] = HOLE;
    game->static_grid[4][4] = HOLE;

    int placed = 0;
    while (placed < nbMushrooms)
    {
        int rx = rand() % GAME_GRID_SIZE;
        int ry = rand() % GAME_GRID_SIZE;
        if (game->static_grid[ry][rx] == EMPTY || game->static_grid[ry][rx]== HOLE)
        {
            game->static_grid[ry][rx] = MUSHROOM;
            placed++;
        }
    }
}

static void RandomizeWinState(GameCore* game, int nbRabbits, int nbFoxes)
{
    GameState* state = &game->current_state;
    state->piece_count = 0;
    Vec2 holes[] = { {0,4}, {4,4}, {2,2}, {0,0}, {4,0} };
    int maxHoles = 5;

    // Mélange des trous 
    for (int i = 0; i < maxHoles; i++)
    {
        int r = rand() % maxHoles;
        Vec2 temp = holes[i];
        holes[i] = holes[r];
        holes[r] = temp;
    }

    int rabbitsToPlace = (nbRabbits > maxHoles) ? maxHoles : nbRabbits;
    for (int i = 0; i < rabbitsToPlace; i++)
    {
        state->pieces[state->piece_count++] = (Piece){
            .id = (uint8_t)(i + 1),
            .type = RABBIT,
            .x = (uint8_t)holes[i].x,
            .y = (uint8_t)holes[i].y,
            .orientation = 0
        };
    }

    int foxesPlaced = 0;
    while (foxesPlaced < nbFoxes)
    {
        int rx = rand() % GAME_GRID_SIZE;
        int ry = rand() % GAME_GRID_SIZE;
        int orient = rand() % 2;

        if (orient == ORIENTATION_VERTICAL)
        {
            if (rx == 0 || rx == 2 || rx == 4) continue;
        }
        else
        {
            if (ry == 0 || ry == 2 || ry == 4) continue;
        }
        if (!IsCellFreeForPlacement(game, rx, ry)) continue;
        int tx = (orient == ORIENTATION_VERTICAL) ? rx : rx + 1;
        int ty = (orient == ORIENTATION_VERTICAL) ? ry + 1 : ry;
        if (tx >= GAME_GRID_SIZE || ty >= GAME_GRID_SIZE) continue;
        if (!IsCellFreeForPlacement(game, tx, ty)) continue;

        state->pieces[state->piece_count++] = (Piece){
            .id = (uint8_t)(10 + foxesPlaced),
            .type = FOX_HEAD,
            .x = (uint8_t)rx,
            .y = (uint8_t)ry,
            .orientation = (uint8_t)orient
        };
        foxesPlaced++;
    }
}

static int ComputeTrueDifficulty(const GameCore* game, const GameState* startState)
{
    GenQueue q;
    GenQueue_init(&q);

    GameHashmap visited;
    GameHashmap_init(&visited, 60000);
    GenQueue_push(&q, *startState, 0);
    GameHashmap_insert(&visited, startState, NULL);

    while (!GenQueue_isEmpty(&q))
    {
        int depth;
        GameState current = GenQueue_pop(&q, &depth);

        if (IsWinningState(&current, game->static_grid))
        {
            GenQueue_free(&q);
            GameHashmap_destroy(&visited);
            return depth; // Distance minimale trouvée
        }

        if (depth > 60) break;

        for (int i = 0; i < current.piece_count; i++)
        {
            for (int dir = 0; dir < 4; dir++)
            {
                GameState nextState;
                if (GameCore_tryMove(game, &current, i, dir, &nextState))
                {
                    if (GameHashmap_insert(&visited, &nextState, &current))
                    {
                        GenQueue_push(&q, nextState, depth + 1);
                    }
                }
            }
        }
    }
    GenQueue_free(&q);
    GameHashmap_destroy(&visited);
    return -1;
}


void GameGenerate_level(GameCore* game, int nbRabbits, int nbFoxes, int nbMushrooms, int minMoves, int maxMoves)
{
    printf("GENERATION (Lapins:%d, Renards:%d, Champis:%d) - Objectif: %d-%d coups\n", nbRabbits, nbFoxes, nbMushrooms, minMoves, maxMoves);

    FullLevel bestLevel = { 0 };
    bestLevel.difficulty = -1;

    GenQueue q;
    GenQueue_init(&q);

    GameHashmap visited;
    GameHashmap_init(&visited, HASHMAP_INITIAL_CAPACITY);

    int maxAttempts = (minMoves > 15) ? 2000 : 50;

    for (int attempt = 0; attempt < maxAttempts; attempt++)
    {
        RandomPlacement(game, nbMushrooms);
        RandomizeWinState(game, nbRabbits, nbFoxes);

        GenQueue_clear(&q);

        // reset manuel hashmap
        memset(visited.m_idMap, -1, visited.m_capacity * sizeof(int));
        visited.m_size = 0;

        GameState endState = game->current_state;
        GenQueue_push(&q, endState, 0);
        GameHashmap_insert(&visited, &endState, NULL);

        GameState furthestState = endState;
        int maxDepth = 0;

        while (!GenQueue_isEmpty(&q))
        {
            int depth;
            GameState current = GenQueue_pop(&q, &depth);

            // état gagnant ? (reverse BFS), profondeur 0
            if (IsWinningState(&current, game->static_grid))
            {
                depth = 0;
            }

            if (depth > maxDepth)
            {
                maxDepth = depth;
                furthestState = current;
            }

            // limitation de la profondeur de recherche inverse
            if (depth > maxMoves) continue;

            for (int i = 0; i < current.piece_count; i++)
            {
                for (int dir = 0; dir < 4; dir++)
                {
                    GameState nextState;
                    // utilisation de la tentative de mouvement pour simuler
                    if (GameCore_tryMove(game, &current, i, dir, &nextState))
                    {
                        if (GameHashmap_insert(&visited, &nextState, &current))
                        {
                            GenQueue_push(&q, nextState, depth + 1);
                        }
                    }
                }
            }
        }
        // Si le BFS inverse a trouvé un "bon niveau"
        if (maxDepth >= bestLevel.difficulty)
        {
            GameState oldState = game->current_state;
            game->current_state = furthestState; // placement des pièces ici pour le test
            int trueDifficulty = ComputeTrueDifficulty(game, &furthestState);
            game->current_state = oldState; // Restore

            // meilleur niveau que le précédent ?
            if (trueDifficulty > bestLevel.difficulty)
            {
                bestLevel.difficulty = trueDifficulty;
                bestLevel.piecesState = furthestState;
                memcpy(bestLevel.staticGrid, game->static_grid, sizeof(game->static_grid)); //copie l'état de la grille actuelle pour la mettre dans best level

                if (trueDifficulty >= minMoves && trueDifficulty <= maxMoves)
                {
                    printf("----> SUCCES: Niveau trouve (%d coups) a l'essai %d.\n", trueDifficulty, attempt + 1);
                    break;
                }
            }
        }
    }

    GenQueue_free(&q);
    GameHashmap_destroy(&visited);

    if (bestLevel.difficulty != -1)
    {
        memcpy(game->static_grid, bestLevel.staticGrid, sizeof(game->static_grid));
        game->initial_state = bestLevel.piecesState;
        game->current_state = bestLevel.piecesState;
        game->moves_count = 0;
        printf("Application du niveau genere. Difficulte finale : %d.\n", bestLevel.difficulty);
    }
    else
    {
        printf("ECHEC GENERATION : Aucun niveau valide trouve. Fallback.\n");
    }
}
