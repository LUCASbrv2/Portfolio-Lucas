#include "game/core/game_hashmap.h"
#include <stdlib.h> 
#include <string.h> 
#include <stdio.h>  

#define INVALID_INDEX -1

static uint64_t GameHashmap_state(const GameState* state)
{
    uint64_t hash = 0;

    for (int i = 0; i < state->piece_count; i++)
    {
        const Piece* p = &state->pieces[i];

        // Pos X
        hash ^= (uint64_t)(p->x);
        hash = hash * 0xbf58476d1ce4e5b9ULL + 0x9e3779b97f4a7c15ULL;

        // Pos Y
        hash ^= (uint64_t)(p->y);
        hash = hash * 0xbf58476d1ce4e5b9ULL + 0x9e3779b97f4a7c15ULL;

        // Orientation
        hash ^= (uint64_t)(p->orientation);
        hash = hash * 0xbf58476d1ce4e5b9ULL + 0x9e3779b97f4a7c15ULL;
    }
    return hash;
}

static bool GameHashmap_StateEqual(const GameState* s1, const GameState* s2)
{
    if (s1->piece_count != s2->piece_count) return false;
    return memcmp(s1->pieces, s2->pieces, sizeof(Piece) * s1->piece_count) == 0;
}

static void GameHashmap_resize(GameHashmap* map)
{
    int old_capacity = map->m_capacity;
    int new_capacity = old_capacity * 2;

    int* new_idMap = (int*)malloc(sizeof(int) * new_capacity);
    GameHashmapEntry* new_entries = (GameHashmapEntry*)malloc(sizeof(GameHashmapEntry) * new_capacity);

    if (!new_idMap || !new_entries)
    {
        fprintf(stderr, "Erreur fatale : Echec allocation memoire resize hashmap.\n");
        exit(EXIT_FAILURE);
    }

    // Initialisation
    for (int i = 0; i < new_capacity; i++)
    {
        new_idMap[i] = INVALID_INDEX;
    }
    // Copie des entrées
    memcpy(new_entries, map->m_entries, sizeof(GameHashmapEntry) * map->m_size);

    // Rehashage
    for (int i = 0; i < map->m_size; i++)
    {
        GameState* state = &new_entries[i].currState;
        uint64_t h = GameHashmap_state(state);
        int idx = h % new_capacity;

        while (new_idMap[idx] != INVALID_INDEX)
        {
            idx = (idx + 1) % new_capacity;
        }
        new_idMap[idx] = i;
    }

    free(map->m_idMap);
    free(map->m_entries);

    map->m_idMap = new_idMap;
    map->m_entries = new_entries;
    map->m_capacity = new_capacity;
}

// fonctions publics

void GameHashmap_init(GameHashmap* map, int initial_capacity)
{
    map->m_capacity = initial_capacity;
    map->m_size = 0;

    map->m_idMap = (int*)malloc(sizeof(int) * map->m_capacity);
    map->m_entries = (GameHashmapEntry*)malloc(sizeof(GameHashmapEntry) * map->m_capacity);

    if (!map->m_idMap || !map->m_entries)
    {
        fprintf(stderr, "Erreur fatale : Echec allocation memoire hashmap init.\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < map->m_capacity; i++)
    {
        map->m_idMap[i] = INVALID_INDEX;
    }
}

void GameHashmap_destroy(GameHashmap* map)
{
    if (map)
    {
        if (map->m_idMap) free(map->m_idMap);
        if (map->m_entries) free(map->m_entries);
        map->m_idMap = NULL;
        map->m_entries = NULL;
        map->m_size = 0;
        map->m_capacity = 0;
    }
}

bool GameHashmap_insert(GameHashmap* map, const GameState* current, const GameState* prev)
{
    uint64_t h = GameHashmap_state(current);
    int idx = (int)(h % map->m_capacity);

    // Recherche
    while (map->m_idMap[idx] != INVALID_INDEX)
    {
        int entryIndex = map->m_idMap[idx];
        GameState* existingState = &map->m_entries[entryIndex].currState;

        if (GameHashmap_StateEqual(current, existingState))
        {
            return false;
        }
        idx = (idx + 1) % map->m_capacity;
    }

    // Insertion
    if (map->m_size >= map->m_capacity / 2)
    {
        GameHashmap_resize(map);
        return GameHashmap_insert(map, current, prev);
    }

    int newEntryIndex = map->m_size;
    map->m_entries[newEntryIndex].currState = *current;

    if (prev)
    {
        map->m_entries[newEntryIndex].prevState = *prev;
    }
    else
    {
        memset(&map->m_entries[newEntryIndex].prevState, 0, sizeof(GameState));
    }

    map->m_idMap[idx] = newEntryIndex;
    map->m_size++;

    return true;
}

const GameState* GameHashmap_getParent(GameHashmap* map, const GameState* current)
{
    uint64_t h = GameHashmap_state(current);
    int idx = h % map->m_capacity;

    while (map->m_idMap[idx] != INVALID_INDEX)
    {
        int entryIndex = map->m_idMap[idx];
        GameHashmapEntry* entry = &map->m_entries[entryIndex];

        if (GameHashmap_StateEqual(current, &entry->currState))
        {
            return &entry->prevState;
        }
        idx = (idx + 1) % map->m_capacity;
    }
    return NULL;
}
