#pragma once

#include "game/core/game_core.h"
#include <stdbool.h>

typedef struct
{
    GameState* data;
    int* depths;
    int head,
    tail,
    count,
    capacity;
} GenQueue;

void GameGenerate_level(GameCore* game, int nbRabbits, int nbFoxes, int nbMushrooms, int minMoves, int maxMoves);


// structure interne pour stocker le meilleur niveau trouvé
typedef struct
{
    int difficulty;
    GameState piecesState;
    uint8_t staticGrid[GAME_GRID_SIZE][GAME_GRID_SIZE];
} FullLevel;

