#pragma once

#include "game/core/game_core.h" 
#include <stdbool.h>             



// contient l'état actuel et son parent
typedef struct GameHashmapEntry
{
    GameState prevState;
    GameState currState;
} GameHashmapEntry;

// table de hachage 
typedef struct GameHashmap
{
    GameHashmapEntry* m_entries; // tableau contigu des états
    int* m_idMap;                // table d'indices 
    int m_capacity;              // capacité actuelle
    int m_size;                  // nb d'éléments stockés
} GameHashmap;


void GameHashmap_init(GameHashmap* map, int initial_capacity);
void GameHashmap_destroy(GameHashmap* map);
bool GameHashmap_insert(GameHashmap* map, const GameState* current, const GameState* prev);

const GameState* GameHashmap_getParent(GameHashmap* map, const GameState* current);

static uint64_t GameHashmap_state(const GameState* state);
static bool GameHashmap_StateEqual(const GameState* s1, const GameState* s2);
static void GameHashmap_resize(GameHashmap* map);




