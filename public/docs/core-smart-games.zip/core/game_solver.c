#include "game/core/game_solver.h"
#include "game/core/game_hashmap.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


static void Solver_InitQueue(SolverQueue* q)
{
    q->capacity = 200000;
    q->data = (GameState*)malloc(sizeof(GameState) * q->capacity);
    q->head = 0;
    q->tail = 0;
    q->count = 0;
}
static void Solver_FreeQueue(SolverQueue* q)
{
    free(q->data);
}
static void Solver_Push(SolverQueue* q, GameState s)
{
    if (q->count >= q->capacity) return;
    q->data[q->tail] = s;
    q->tail = (q->tail + 1) % q->capacity;
    q->count++;
}
static GameState Solver_Pop(SolverQueue* q)
{
    GameState s = q->data[q->head];
    q->head = (q->head + 1) % q->capacity;
    q->count--;
    return s;
}
static bool Solver_IsEmpty(SolverQueue* q)
{
    return q->count == 0;
}

static bool IsWinning(const GameCore* game, const GameState* s)
{
    for (int i = 0; i < s->piece_count; i++)
    {
        if (s->pieces[i].type == RABBIT)
        {
            int vRow = GAME_GRID_SIZE - 1 - s->pieces[i].y;
            if (game->static_grid[vRow][s->pieces[i].x] != HOLE) return false;
        }
    }
    return true;
}

static Solution ReconstructPath(GameHashmap* map, GameState endState)
{
    Solution sol = { 0 };
    sol.found = true;
    sol.count = 0;

    GameState path[200];
    int depth = 0;
    GameState curr = endState;

    path[depth++] = curr;
    while (true)
    {
        const GameState* parent = GameHashmap_getParent(map, &curr);
        if (!parent) break;
        curr = *parent;
        path[depth++] = curr;
        if (depth >= 200) break;
    }

    for (int i = depth - 1; i > 0; i--)
    {
        GameState* from = &path[i];
        GameState* to = &path[i - 1];

        for (int p = 0; p < from->piece_count; p++)
        {
            if (from->pieces[p].x != to->pieces[p].x || from->pieces[p].y != to->pieces[p].y)
            {
                Move m;
                m.pieceIndex = p;
                m.fromX = from->pieces[p].x;
                m.fromY = from->pieces[p].y;
                m.toX = to->pieces[p].x;
                m.toY = to->pieces[p].y;

                if (m.toY > m.fromY) m.direction = 0;
                else if (m.toY < m.fromY) m.direction = 1;
                else if (m.toX < m.fromX) m.direction = 2;
                else m.direction = 3;

                sol.moves[sol.count++] = m;
                break;
            }
        }
    }
    return sol;
}

Solution GameSolver_solve(GameCore* game)
{
    Solution sol = { 0 };
    sol.found = false;

    SolverQueue q;
    Solver_InitQueue(&q);

    GameHashmap visited;
    GameHashmap_init(&visited, 60000);

    GameState start = game->current_state;
    Solver_Push(&q, start);
    GameHashmap_insert(&visited, &start, NULL);

    int explored = 0;
    bool found = false;
    GameState winState = { 0 };

    while (!Solver_IsEmpty(&q))
    {
        GameState curr = Solver_Pop(&q);
        explored++;

        if (explored > 200000) break;

        if (IsWinning(game, &curr))
        {
            found = true;
            winState = curr;
            break;
        }

        for (int i = 0; i < curr.piece_count; i++)
        {
            for (int dir = 0; dir < 4; dir++)
            {
                GameState next;
                if (GameCore_tryMove(game, &curr, i, dir, &next))
                {
                    if (GameHashmap_insert(&visited, &next, &curr))
                    {
                        Solver_Push(&q, next);
                    }
                }
            }
        }
    }

    if (found)
    {
        sol = ReconstructPath(&visited, winState);
    }

    Solver_FreeQueue(&q);
    GameHashmap_destroy(&visited);
    return sol;
}

