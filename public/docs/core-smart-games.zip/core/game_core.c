/*
    Copyright (c) Arnaud BANNIER, Nicolas BODIN.
    Licensed under the MIT License.
    See LICENSE.md in the project root for license information.
*/
#include "game/core/game_core.h"
#include <stdlib.h>
#include <string.h>

void GameCore_buildFullGrid(const GameCore* game, const GameState* state, uint8_t grid[GAME_GRID_SIZE][GAME_GRID_SIZE])
{
    for (int y = 0; y < GAME_GRID_SIZE; y++)
    {
        for (int x = 0; x < GAME_GRID_SIZE; x++)
        {
            int visualRow = GAME_GRID_SIZE - 1 - y;
            grid[y][x] = game->static_grid[visualRow][x];
        }
    }

    // ajout des pièces mobiles (qui sont déjà en coordonnées logiques)
    for (int i = 0; i < state->piece_count; i++)
    {
        const Piece* p = &state->pieces[i];
        if (p->type == RABBIT)
        {
            grid[p->y][p->x] = RABBIT;
        }
        else if (p->type == FOX_HEAD)
        {
            grid[p->y][p->x] = FOX_HEAD;
            if (p->orientation == ORIENTATION_VERTICAL)
            {
                if (p->y + 1 < GAME_GRID_SIZE) grid[p->y + 1][p->x] = FOX_TAIL;
            }
            else
            {
                if (p->x + 1 < GAME_GRID_SIZE) grid[p->y][p->x + 1] = FOX_TAIL;
            }
        }
    }
}

bool GameCore_tryMove(const GameCore* game, const GameState* current, int piece_idx, int direction, GameState* new_state)
{
    Piece p = current->pieces[piece_idx];

    // construit la grille en coordonnées logiques 
    uint8_t grid[GAME_GRID_SIZE][GAME_GRID_SIZE];
    GameCore_buildFullGrid(game, current, grid);

    int dx = 0, dy = 0;
    // direction: 0=Haut,1=Bas,2=Gauche,3=Droite
    if (direction == 0) dy = -1;
    else if (direction == 1) dy = 1;
    else if (direction == 2) dx = -1;
    else if (direction == 3) dx = 1;

    // LAPIN paterns
    if (p.type == RABBIT)
    {
        int obstacles_jumped = 0;
        int cx = p.x;
        int cy = p.y;

        while (true)
        {
            cx += dx;
            cy += dy;

            if (cx < 0 || cx >= GAME_GRID_SIZE || cy < 0 || cy >= GAME_GRID_SIZE) return false;

            // On lit la grille avec les champignons au bon endroit
            uint8_t cell = grid[cy][cx];

            bool is_obstacle = (cell == RABBIT || cell == FOX_HEAD || cell == FOX_TAIL || cell == MUSHROOM);
            bool is_landing_spot = !is_obstacle;

            if (is_obstacle)
            {
                obstacles_jumped++;
            }
            else if (is_landing_spot)
            {
                if (obstacles_jumped > 0)
                {
                    if (new_state)
                    {
                        *new_state = *current;
                        new_state->pieces[piece_idx].x = cx;
                        new_state->pieces[piece_idx].y = cy;
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
    // RENARD paterns
    else if (p.type == FOX_HEAD)
    {
        if (p.orientation == ORIENTATION_VERTICAL && dx != 0) return false; //empeche le mouvement en x
        if (p.orientation == ORIENTATION_HORIZONTAL && dy != 0) return false; //empeche le mouvement en y

        int nx = p.x + dx; //position de la tête head (nx, ny)
        int ny = p.y + dy;
        int tx = (p.orientation == ORIENTATION_VERTICAL) ? nx : nx + 1; //position de la queue tail (tx, ty)
        int ty = (p.orientation == ORIENTATION_VERTICAL) ? ny + 1 : ny;

        if (nx < 0 || nx >= GAME_GRID_SIZE || ny < 0 || ny >= GAME_GRID_SIZE) return false;
        if (tx < 0 || tx >= GAME_GRID_SIZE || ty < 0 || ty >= GAME_GRID_SIZE) return false;

        if (grid[ny][nx] == MUSHROOM) return false;
        if (grid[ty][tx] == MUSHROOM) return false;

        // obstacles DYNAMIQUES (autres animaux)
        // On parcourt toutes les pièces pour voir si on rentre dedans
        for (int i = 0; i < current->piece_count; i++)
        {
            // on s'ignore soi-même pour ne pas se bloquer
            if (i == piece_idx) continue;

            const Piece* other = &current->pieces[i];

            // Coordonnées de l'autre pièce (Tête)
            int ox = other->x;
            int oy = other->y;

            // Collision avec la tête de l'autre ?
            // (ma nouvelle tête ou ma nouvelle queue touche SA tête ?)
            if ((nx == ox && ny == oy) || (tx == ox && ty == oy)) return false;

            // Si l'autre est un RENARD, il faut aussi tester sa QUEUE
            if (other->type == FOX_HEAD)
            {
                int otx = (other->orientation == ORIENTATION_VERTICAL) ? ox : ox + 1;
                int oty = (other->orientation == ORIENTATION_VERTICAL) ? oy + 1 : oy;

                // Collision avec la queue de l'autre ?
                if ((nx == otx && ny == oty) || (tx == otx && ty == oty)) return false;
            }
        }

        if (new_state)
        {
            *new_state = *current;
            new_state->pieces[piece_idx].x = nx;
            new_state->pieces[piece_idx].y = ny;
        }
        return true;
    }

    return false;
}

// vérif victoire 

bool GameCore_checkWin(const GameCore* game)
{
    const GameState* state = &game->current_state;

    for (int i = 0; i < state->piece_count; i++)
    {
        const Piece* p = &state->pieces[i];

        if (p->type == RABBIT)
        {
            // Conversion Coordonnée Logique -> Ligne Visuelle pour lire static_grid
            int visualRow = GAME_GRID_SIZE - 1 - p->y;

            if (game->static_grid[visualRow][p->x] != HOLE)
            {
                return false;
            }
        }
    }

    return true;
}
